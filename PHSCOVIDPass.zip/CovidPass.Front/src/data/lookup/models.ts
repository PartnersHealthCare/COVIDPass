// © 2020 Partners HealthCare Technology & Innovation Department
export interface PatientInfo {
  employeeNumber: string;
  lastName: string;
  firstName: string;
  departmentName: string;
  departmentNumber: string;
  username: string;
  email: string;
}
