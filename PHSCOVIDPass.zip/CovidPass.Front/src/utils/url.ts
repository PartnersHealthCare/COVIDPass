// © 2020 Partners HealthCare Technology & Innovation Department
export const appUrlPath = '/employee';
