// © 2020 Partners HealthCare Technology & Innovation Department
namespace CovidPass.Core
{
    public class Anchor
    {
    }
}
