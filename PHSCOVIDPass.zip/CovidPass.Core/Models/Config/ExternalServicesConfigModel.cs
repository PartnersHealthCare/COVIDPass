// © 2020 Partners HealthCare Technology & Innovation Department
namespace CovidPass.Core.Models.Config
{
    public class ExternalServicesConfigModel
    {
        public string Login { get; set; }
        public string Password { get; set; }
        public string CensusUrl { get; set; }
    }
}
