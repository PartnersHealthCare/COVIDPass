// © 2020 Partners HealthCare Technology & Innovation Department
namespace CovidPass.Core.Models.Config
{
    public class ResetCounterConfig
    {
        public string Cron { get; set; }
    }
}
