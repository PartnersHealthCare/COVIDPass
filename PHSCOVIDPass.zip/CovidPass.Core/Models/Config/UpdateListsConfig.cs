// © 2020 Partners HealthCare Technology & Innovation Department
namespace CovidPass.Core.Models.Config
{
    public class UpdateListsConfig
    {
        public int UpdateEvery { get; set; }
    }
}
