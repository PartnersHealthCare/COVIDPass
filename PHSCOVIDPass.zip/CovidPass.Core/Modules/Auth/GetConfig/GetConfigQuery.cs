// © 2020 Partners HealthCare Technology & Innovation Department
using CovidPass.Core.Infrastructure.Models;

namespace CovidPass.Core.Modules.Auth.GetConfig
{
    public class GetConfigQuery : Query<Config>
    {
    }
}
