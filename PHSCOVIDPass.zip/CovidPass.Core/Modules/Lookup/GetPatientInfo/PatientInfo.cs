// © 2020 Partners HealthCare Technology & Innovation Department
namespace CovidPass.Core.Modules.Lookup.GetPatientInfo
{
    public class PatientInfo
    {
        public string EmployeeNumber { get; set; }
        public string LastName { get; set; }
        public string FirstName { get; set; }
        public string DepartmentName { get; set; }
        public string DepartmentNumber { get; set; }
        public string Username { get; set; }
        public string Email { get; set; }
    }
}
