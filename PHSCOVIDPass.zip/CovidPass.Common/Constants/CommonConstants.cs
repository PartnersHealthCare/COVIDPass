// © 2020 Partners HealthCare Technology & Innovation Department
namespace CovidPass.Common.Constants
{
    public class CommonConstants
    {
        public const int PageSize = 25;
        public const string EmailRegex = "(^$)|(^([a-zA-Z0-9$!#$%&'*\\+\\-\\/=?^_`{|}~]+(\\.[a-zA-Z0-9$!#$%&'*\\+\\-\\/=?^_`{|}~]+)*)@[a-zA-Z0-9]+(-[a-zA-Z0-9]+)*\\.[a-zA-Z]{2,}$)";
    }
}
